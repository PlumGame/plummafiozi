// src/pages/Game.jsx
import React, { useEffect, useState, useRef } from 'react';
import { useParams, useLocation, useNavigate } from 'react-router-dom';
import '../index.css';
import { fetchGameByCode, getMyRole, fetchPlayers } from '../lib/rooms';

export default function Game() {
  const { code } = useParams();
  const location = useLocation();
  const nav = useNavigate();

  const initialPlayerId = (location.state && location.state.playerId) || localStorage.getItem('playerId');
  const initialGameId = (location.state && location.state.gameId) || null;

  const [game, setGame] = useState(null);
  const [players, setPlayers] = useState([]);
  const [myRole, setMyRole] = useState(null);
  const [revealed, setRevealed] = useState(false);
  const [loading, setLoading] = useState(true);
  const pollRef = useRef(null);

  const loadAll = async () => {
    try {
      // fetchGameByCode возвращает { data, error }
      const { data: g, error: gameErr } = await fetchGameByCode(code);
      if (gameErr) {
        console.error('fetchGameByCode error', gameErr);
      } else {
        setGame(g || null);
      }

      const { data: pls, error: plsErr } = await fetchPlayers(code);
      if (plsErr) {
        console.error('fetchPlayers error', plsErr);
      } else {
        setPlayers(pls || []);
      }

      // Если game id не передан, возьмём из g
      const gameId = initialGameId || (g && g.id);
      if (!initialPlayerId) {
        console.warn('No playerId available (localStorage or location.state). Role cannot be fetched.');
        return;
      }
      if (gameId) {
        const { data: roleRow, error: roleErr } = await getMyRole(initialPlayerId, gameId);
        if (roleErr) {
          console.warn('getMyRole error', roleErr);
        } else if (roleRow) {
          setMyRole(roleRow);
        } else {
          console.warn('getMyRole returned no row for player', initialPlayerId, 'game', gameId);
        }
      } else {
        console.warn('No gameId available yet to fetch role');
      }
    } catch (e) {
      console.error('loadAll exception', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    // если нет кода — уходим
    if (!code) {
      nav('/');
      return;
    }

    // начальная загрузка
    setLoading(true);
    loadAll();

    // polling (fallback). Можно заменить на realtime подписку.
    pollRef.current = setInterval(loadAll, 1500);

    return () => {
      if (pollRef.current) clearInterval(pollRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [code]); // не включаем loadAll в зависимости, чтобы не создавать лишние интервалы

  // Если игра не в состоянии running — можно вернуть в лобби или показать сообщение
  useEffect(() => {
    if (!game) return;
    if (game.state === 'lobby') {
      // Если пользователь случайно попал на /game до старта — можно вернуть в лобби
      // nav(`/lobby/${code}`);
    }
  }, [game, code, nav]);

  const roleName = myRole && myRole.role ? myRole.role : null;
  const roleImageSrc = roleName ? `/assets/roles/${roleName}.png` : null;

  return (
    <div className="screen-center">
      <div className="card" style={{ maxWidth: 720 }}>
        <h2>Игра — {code}</h2>
        <div>
          Состояние: <strong>{game ? game.state : (loading ? 'загрузка...' : 'не найдена')}</strong>
          {' '}| День: {game ? (game.day ?? '—') : '—'}
        </div>

        <div style={{ marginTop: 18 }}>
          <h3>Ваша роль</h3>

          {!myRole && !loading && <div>Роль не найдена или ещё не назначена</div>}
          {!myRole && loading && <div>Роль загружается…</div>}

          {myRole && (
            <div style={{ display: 'flex', gap: 18, alignItems: 'center' }}>
              <div>
                <div style={{ fontWeight: 800, fontSize: 18 }}>{roleName}</div>
                <div style={{ color: myRole.is_alive ? '#9ee29e' : '#ff6b6b' }}>
                  {myRole.is_alive ? 'Вы живы' : 'Вы выбиты'}
                </div>
              </div>

              <div>
                {!revealed ? (
                  <button className="glow-btn" onClick={() => setRevealed(true)} style={{ padding: '8px 12px' }}>
                    Показать карточку роли
                  </button>
                ) : (
                  <div style={{ width: 220, textAlign: 'center' }}>
                    {roleImageSrc ? (
                      <img src={roleImageSrc} alt={roleName} style={{ width: '220px', borderRadius: 8, boxShadow: '0 6px 18px rgba(0,0,0,0.4)' }} />
                    ) : (
                      <div style={{ padding: 20, borderRadius: 8, background: '#222', color: '#fff' }}>
                        Нет изображения для роли: {roleName}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        <div style={{ marginTop: 18 }}>
          <h3>Игроки ({players.length})</h3>
          <ul>
            {players.map(p => (
              <li key={p.id}>
                {p.name} {p.id === initialPlayerId ? '(Вы)' : ''} {p.is_host ? ' (host)' : ''}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
